export class UserInfo {
    token: string;
    email: string;
    role: role;
    message:string;
    lienPhoto:string;
    pseudo:string;
    id:string;
}