import { MessageEntity } from './message.entity';

describe('MessageEntity', () => {
  it('should be defined', () => {
    expect(new MessageEntity()).toBeDefined();
  });
});
