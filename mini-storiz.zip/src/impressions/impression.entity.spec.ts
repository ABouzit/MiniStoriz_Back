import { ImpressionEntity } from './impression.entity';

describe('ImpressionEntity', () => {
  it('should be defined', () => {
    expect(new ImpressionEntity()).toBeDefined();
  });
});
