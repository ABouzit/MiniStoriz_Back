import { RelationEntity } from './relation.entity';

describe('RelationEntity', () => {
  it('should be defined', () => {
    expect(new RelationEntity()).toBeDefined();
  });
});
