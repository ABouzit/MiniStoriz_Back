import { BloquerEntity } from './bloquer.entity';

describe('BloquerEntity', () => {
  it('should be defined', () => {
    expect(new BloquerEntity()).toBeDefined();
  });
});
