import { PlancheEntity } from './planche.entity';

describe('PlancheEntity', () => {
  it('should be defined', () => {
    expect(new PlancheEntity()).toBeDefined();
  });
});
