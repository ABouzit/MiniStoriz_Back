 enum  role {
    'USER'= 'USER', 'ADMIN'= 'ADMIN'
}