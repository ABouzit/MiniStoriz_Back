enum envoyeePar {
    'ONE', 'TWO',
}