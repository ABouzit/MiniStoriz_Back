import { HistoireEntity } from './histoire.entity';

describe('HistoireEntity', () => {
  it('should be defined', () => {
    expect(new HistoireEntity()).toBeDefined();
  });
});
